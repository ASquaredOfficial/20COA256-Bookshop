
public enum BookType {
	AudioBook,
	eBook,
	Paperback;	
}
