
public enum PaymentType {
	PayPal,
	CreditCard;
}
