

public enum Language {
	English,
	French;
}
