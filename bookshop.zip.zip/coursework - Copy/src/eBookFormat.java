

public enum eBookFormat {
	EPUB,
	MOBI,
	AZW3,
	PDF;	
}
