

public enum AudioFormat {
	MP3,
	WMA,
	AAC;
}
