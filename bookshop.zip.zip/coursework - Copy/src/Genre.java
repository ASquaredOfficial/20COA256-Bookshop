

public enum Genre {
	ComputerScience,
	Business,
	Medicine,
	Politics,
	Biography;
	
}
