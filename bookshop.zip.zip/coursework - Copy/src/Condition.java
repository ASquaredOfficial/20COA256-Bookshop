

public enum Condition {
	newBook,
	usedBook;
	
	
}
